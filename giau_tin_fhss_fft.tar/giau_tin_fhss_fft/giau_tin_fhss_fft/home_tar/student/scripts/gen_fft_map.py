import random

try:
    with open('../binary_message.txt', 'r') as f:
        bits = f.read()
    
    # FHSS: Mỗi bit tương ứng với một bước nhảy tần số ngẫu nhiên
    hopping_pattern = [random.randint(100, 1000) for _ in range(len(bits))]
    
    with open('../hopping_pattern.txt', 'w') as f:
        f.write(','.join(map(str, hopping_pattern)))
    print("SUCCESS: Da tao hopping_pattern.txt cho FHSS.")
except Exception as e:
    print(f"ERROR: {e}")
