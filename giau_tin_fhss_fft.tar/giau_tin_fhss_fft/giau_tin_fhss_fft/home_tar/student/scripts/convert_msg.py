import os

def text_to_bin(message):
    return ''.join(format(ord(c), '08b') for c in message)

try:
    # Đọc tin nhắn từ thư mục cha (student/)
    with open('../message.txt', 'r') as file:
        message = file.read().strip()
    
    binary_message = text_to_bin(message)
    
    # Lưu kết quả ra file nhị phân
    with open('../binary_message.txt', 'w') as f:
        f.write(binary_message)
    print("SUCCESS: Da chuyen message.txt sang binary_message.txt")
except Exception as e:
    print(f"ERROR: {e}")
