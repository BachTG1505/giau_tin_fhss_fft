import numpy as np
from scipy.io import wavfile

try:
    # 1. Đọc file âm thanh gốc
    fs, signal = wavfile.read('../original_audio.wav')
    
    # 2. Chuyển sang miền tần số bằng FFT
    signal_fft = np.fft.fft(signal)
    
    # 3. Đọc dãy nhảy tần
    with open('../hopping_pattern.txt', 'r') as f:
        pattern = [int(x) for x in f.read().split(',')]
        
    # 4. Nhúng tin: Thay đổi biên độ tại các bins tần số tương ứng
    for i in range(min(len(pattern), len(signal_fft))):
        signal_fft[i] += pattern[i] * 0.01
        
    # 5. Nghịch đảo FFT (IFFT) để về lại âm thanh
    stego_signal = np.fft.ifft(signal_fft).real
    
    # 6. Lưu file kết quả để chấm điểm
    wavfile.write('../stego_audio.wav', fs, stego_signal.astype(np.int16))
    print("SUCCESS: Da tao file stego_audio.wav thanh cong!")
except Exception as e:
    print(f"ERROR: {e}")
